package p1.exceptions;

public class Invalid_value extends Exception{

	public Invalid_value() {
		super("Value in the equation is invalid");
		// TODO Auto-generated constructor stub
	}

	public Invalid_value(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
