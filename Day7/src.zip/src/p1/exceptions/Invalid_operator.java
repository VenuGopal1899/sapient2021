package p1.exceptions;

public class Invalid_operator  extends Exception{

	public Invalid_operator() {
		super("Operator/function dose not exisist");
		// TODO Auto-generated constructor stub
	}

	public Invalid_operator(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
