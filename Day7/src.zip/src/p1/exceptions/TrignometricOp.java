package p1.exceptions;

public enum TrignometricOp {
sin,tan,cos,sec;
}
