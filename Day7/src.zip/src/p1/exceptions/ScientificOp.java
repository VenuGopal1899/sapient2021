package p1.exceptions;

public enum ScientificOp {
	
	abs,sqrt;

}
