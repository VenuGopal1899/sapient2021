package p1.runtimepoly;

public class Mul extends Airthmetic{

	@Override
	public double cal(double a, double b) {
		// TODO Auto-generated method stub
		return a * b;
	}
	
	

}
