package p1.runtimepoly;

public abstract  class Airthmetic {

	
	double ans;
	public abstract double cal(double a, double b);
}

